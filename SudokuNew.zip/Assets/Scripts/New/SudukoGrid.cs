﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SudukoGrid : MonoBehaviour
{
    public GameObject cellPrefab;
    public Transform gridParent;
    private SudukoCell[,] grid = new SudukoCell[9, 9];
    private int[,] solution;
  
    void Start()
    {
        GenerateGrid();
        GeneratePuzzle();
    }

    void GenerateGrid()
    {
        float cellSize = 200f; 
        Vector2 startPosition = new Vector2(50,-50); 

        for (int row = 0; row < 9; row++)
        {
            for (int col = 0; col < 9; col++)
            {
                GameObject newCell = Instantiate(cellPrefab, gridParent);
                SudukoCell cell = newCell.GetComponent<SudukoCell>();

                // Set cell position
                RectTransform rectTransform = newCell.GetComponent<RectTransform>();
                rectTransform.anchoredPosition = startPosition + new Vector2(col * cellSize, -row * cellSize);

                // Assign to grid
                grid[row, col] = cell;
                cell.SetCoordinates(row, col);
            }
        }
    }
  /*  void ShuffleRowsAndColumns(int[,] board)
    {
        System.Random rand = new System.Random();

        for (int i = 0; i < 3; i++)
        {
            int baseRow = i * 3;
            int baseCol = i * 3;

            
            for (int j = 0; j < 3; j++)
            {
                int swapRow = baseRow + rand.Next(3);
                SwapRows(board, baseRow + j, swapRow);
            }

           
            for (int j = 0; j < 3; j++)
            {
                int swapCol = baseCol + rand.Next(3);
                SwapColumns(board, baseCol + j, swapCol);
            }
        }
    }

    
    void SwapRows(int[,] board, int rowA, int rowB)
    {
        for (int i = 0; i < 9; i++)
        {
            int temp = board[rowA, i];
            board[rowA, i] = board[rowB, i];
            board[rowB, i] = temp;
        }
    }

   
    void SwapColumns(int[,] board, int colA, int colB)
    {
        for (int i = 0; i < 9; i++)
        {
            int temp = board[i, colA];
            board[i, colA] = board[i, colB];
            board[i, colB] = temp;
        }
    }
*/
    void GeneratePuzzle()
    {
        solution = SudokuSolver.GenerateSudokuSolution();
        int[,] puzzle = (int[,])solution.Clone();

        ShuffleSudoku(puzzle, 20);

        HashSet<(int, int)> fixedCells = new HashSet<(int, int)>();
        Dictionary<int, HashSet<int>> rowFixedNumbers = new Dictionary<int, HashSet<int>>();
        System.Random rand = new System.Random();

        
        for (int i = 0; i < 9; i++)
        {
            rowFixedNumbers[i] = new HashSet<int>();
        }

        while (fixedCells.Count < 40)
        {
            int row = rand.Next(9);
            int col = rand.Next(9);
            int num = puzzle[row, col];

            if (!fixedCells.Contains((row, col)) && !rowFixedNumbers[row].Contains(num))
            {
                fixedCells.Add((row, col));
                rowFixedNumbers[row].Add(num); 

                grid[row, col].SetDraggable(false);
                grid[row, col].SetNumber(num);
                grid[row, col].SetColor(Color.green);
            }
        }

       
        for (int row = 0; row < 9; row++)
        {
            for (int col = 0; col < 9; col++)
            {
                if (!fixedCells.Contains((row, col)))
                {
                    grid[row, col].SetNumber(puzzle[row, col]);
                    grid[row, col].SetDraggable(true);
                }
            }
        }
    }
  
    void ShuffleSudoku(int[,] board, int swaps)
    {
        System.Random rand = new System.Random();

        for (int i = 0; i < swaps; i++)
        {
            int row1 = rand.Next(9);
            int col1 = rand.Next(9);
            int row2 = rand.Next(9);
            int col2 = rand.Next(9);

           
            int temp = board[row1, col1];
            board[row1, col1] = board[row2, col2];
            board[row2, col2] = temp;
        }
    }

    public SudukoCell GetCellAtPosition(Vector3 position)
    {
        foreach (var cell in grid)
        {
            if (RectTransformUtility.RectangleContainsScreenPoint(cell.GetComponent<RectTransform>(), position))
            {
                
                return cell;
            }
        }
        return null;
    }

   

    public bool IsValidMove(int row, int col, int number)
    {
        // Check row
        for (int i = 0; i < 9; i++)
        {
            if (grid[row, i].GetNumber() == number) return false;
        }

        // Check column
        for (int i = 0; i < 9; i++)
        {
            if (grid[i, col].GetNumber() == number) return false;
        }

        // Check 3x3 box
        int startRow = (row / 3) * 3;
        int startCol = (col / 3) * 3;
        for (int i = 0; i < 3; i++)
        {
            for (int j = 0; j < 3; j++)
            {
                if (grid[startRow + i, startCol + j].GetNumber() == number) return false;
            }
        }
        return true;
    }

    private bool IsRowComplete(int row)
    {
        HashSet<int> numbers = new HashSet<int>();
        for (int col = 0; col < 9; col++)
        {
            int num = grid[row, col].GetNumber();
            if (num == 0 || numbers.Contains(num) || num != solution[row, col])
                return false;
            numbers.Add(num);
        }
        return true;
    }

    private bool IsColumnComplete(int col)
    {
        HashSet<int> numbers = new HashSet<int>();
        for (int row = 0; row < 9; row++)
        {
            int num = grid[row, col].GetNumber();
            if (num == 0 || numbers.Contains(num) || num != solution[row, col])
                return false;
            numbers.Add(num);
        }
        return true;
    }

    private void HighlightRow(int row, Color color)
    {
        for (int col = 0; col < 9; col++)
        {
            if (!grid[row, col].IsFixed) 
            {
                grid[row, col].SetColor(color);
            }
        }
    }

    private void HighlightColumn(int col, Color color)
    {
        for (int row = 0; row < 9; row++)
    {
        if (!grid[row, col].IsFixed) 
        {
            grid[row, col].SetColor(color);
        }
    }
    }

    public void CheckWinCondition()
    {
        bool isSudokuSolved = true;

        // Check each row
        for (int row = 0; row < 9; row++)
        {
            if (IsRowComplete(row))
            {
                HighlightRow(row, Color.green);
            }
            else
            {
                isSudokuSolved = false;
                HighlightRow(row, Color.white);
            }
        }

        // Check each column
        for (int col = 0; col < 9; col++)
        {
            if (IsColumnComplete(col))
            {
                HighlightColumn(col, Color.green);
            }
            else
            {
                isSudokuSolved = false;
                HighlightColumn(col, Color.white); 
            }
        }

        if (isSudokuSolved)
        {
            Debug.Log("🎉 Sudoku Solved! 🎉");
            ShowWinMessage();
        }
    }

    void ShowWinMessage()
    {
       
        //reload or chenge secne
        Debug.Log("?? YOU WIN! ??");
    }
}
