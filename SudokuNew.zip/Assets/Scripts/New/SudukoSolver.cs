using System;
using System.Collections.Generic;
using UnityEngine;

public static class SudokuSolver
{
    private static System.Random rng = new System.Random();

    public static int[,] GenerateSudokuSolution()
    {
        int[,] board = new int[9, 9];
        Solve(board);
        return board;
    }

    public static int[,] GeneratePuzzleFromSolution(int[,] solution)
    {
        int[,] puzzle = (int[,])solution.Clone();
        int removeCount = 40; 

        while (removeCount > 0)
        {
            int row = rng.Next(0, 9);
            int col = rng.Next(0, 9);
            if (puzzle[row, col] != 0)
            {
                puzzle[row, col] = 0;
                removeCount--;
            }
        }
        return puzzle;
    }

    private static bool Solve(int[,] board)
    {
        for (int row = 0; row < 9; row++)
        {
            for (int col = 0; col < 9; col++)
            {
                if (board[row, col] == 0)
                {
                    List<int> numbers = GetShuffledNumbers();
                    foreach (int num in numbers)
                    {
                        if (IsValid(board, row, col, num))
                        {
                            board[row, col] = num;
                            if (Solve(board))
                                return true;
                            board[row, col] = 0;
                        }
                    }
                    return false;
                }
            }
        }
        return true;
    }

    private static List<int> GetShuffledNumbers()
    {
        List<int> numbers = new List<int> { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
        numbers.Sort((a, b) => rng.Next(-1, 2));
        return numbers;
    }

    private static bool IsValid(int[,] board, int row, int col, int num)
    {
        for (int i = 0; i < 9; i++)
        {
            if (board[row, i] == num || board[i, col] == num)
                return false;
        }

        int startRow = (row / 3) * 3;
        int startCol = (col / 3) * 3;
        for (int i = 0; i < 3; i++)
        {
            for (int j = 0; j < 3; j++)
            {
                if (board[startRow + i, startCol + j] == num)
                    return false;
            }
        }
        return true;
    }
}
