using System.Collections.Generic;
using UnityEngine;

public class SubGrid : MonoBehaviour
{
    [SerializeField] public List<Cell> cells;
}

