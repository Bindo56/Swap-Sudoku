using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class SudukoCell : MonoBehaviour ,IBeginDragHandler ,IEndDragHandler,IDragHandler
{
    public TextMeshProUGUI numberText;
    private int row, col;
    private bool isDraggable;
    private Vector3 originalPosition;
    private Transform parentTransform;

    void Start()
    {
        parentTransform = transform.parent;
    }

    public void SetCoordinates(int r, int c)
    {
        row = r;
        col = c;
    }

    public void SetNumber(int number)
    {
        numberText.text = number == 0 ? "" : number.ToString();
        numberText.fontSize  = 70;
    }

    public int GetNumber()
    {
        return string.IsNullOrEmpty(numberText.text) ? 0 : int.Parse(numberText.text);
    }

    public void SetDraggable(bool draggable)
    {
        isDraggable = draggable;
    }

    public void OnBeginDrag(PointerEventData eventData)
    {
        if (!isDraggable) return;
        originalPosition = transform.position;
        transform.SetParent(parentTransform.root); // Move to root to avoid masking issues
    }

    public void OnDrag(PointerEventData eventData)
    {
        if (!isDraggable) return;
        transform.position = Input.mousePosition;
    }

    public void OnEndDrag(PointerEventData eventData)
    {/*
        if (!isDraggable) return;

        SudukoCell targetCell = FindObjectOfType<SudukoGrid>().GetCellAtPosition(Input.mousePosition);
        if (targetCell != null && targetCell.isDraggable)
        {
            int newNumber = GetNumber();
            if (FindObjectOfType<SudukoGrid>().IsValidMove(targetCell.row, targetCell.col, newNumber))
            {
                string tempNumber = targetCell.numberText.text;
                targetCell.SetNumber(newNumber);
                SetNumber(string.IsNullOrEmpty(tempNumber) ? 0 : int.Parse(tempNumber));

                FindObjectOfType<SudukoGrid>().CheckWinCondition(); // Check if Sudoku is solved
            }
        }
        transform.position = originalPosition;
        transform.SetParent(parentTransform);*/

         if (!isDraggable) return;

         SudukoGrid gridManager = FindObjectOfType<SudukoGrid>();
         SudukoCell targetCell = gridManager.GetCellAtPosition(Input.mousePosition);

         if (targetCell != null)
         {
             int draggedNumber = GetNumber();
             int targetNumber = targetCell.GetNumber();

             // Swap only if it's not the same number
             if (draggedNumber != targetNumber)
             {
                 targetCell.SetNumber(draggedNumber);
                 SetNumber(targetNumber);
                gridManager.CheckWinCondition(); 
            }
         }

         // Reset position
         transform.position = originalPosition;
    }

   
}
